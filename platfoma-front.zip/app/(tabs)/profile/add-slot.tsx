import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useRouter } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

import { AuthError } from '@/lib/api/auth-error';
import {
  createTutorSlot,
  getTutorSlots,
  type Slot,
} from '@/lib/api/tutor';
import {
  digitsToApiDate,
  digitsToTime,
  formatDateInput,
  formatTimeInput,
  toApiDate,
  toDisplayDate,
  dayFromDate,
  validateDate,
  validateTime,
} from '@/lib/slots-utils';

export default function AddSlotScreen() {
  const router = useRouter();
  const [slots, setSlots] = useState<Slot[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newDate1, setNewDate1] = useState('');
  const [newTime1, setNewTime1] = useState('');
  const [newDate2, setNewDate2] = useState('');
  const [newTime2, setNewTime2] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      getTutorSlots()
        .then((data) => {
          if (!cancelled) setSlots(data);
        })
        .catch((e) => {
          if (!cancelled) {
            if (e instanceof AuthError || e?.name === 'AuthError') {
              router.replace('/login');
              return;
            }
            Alert.alert('Ошибка', e?.message ?? 'Не удалось загрузить слоты');
          }
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
      return () => { cancelled = true; };
    }, [router])
  );

  async function handleSave() {
    setStatusMessage({ text: 'Обработка...', isError: false });

    const raw = [
      { date: newDate1, time: newTime1 },
      { date: newDate2, time: newTime2 },
    ].filter((x) => x.date.trim() || x.time.trim());

    if (raw.length === 0) {
      const msg = 'Введите дату и время для новых слотов';
      setStatusMessage({ text: msg, isError: true });
      Alert.alert('Внимание', msg);
      return;
    }

    for (let i = 0; i < raw.length; i++) {
      const errDate = validateDate(raw[i].date);
      const errTime = validateTime(raw[i].time);
      if (raw[i].date.trim() && errDate) {
        setStatusMessage({ text: errDate, isError: true });
        Alert.alert('Ошибка', errDate);
        return;
      }
      if (raw[i].time.trim() && errTime) {
        setStatusMessage({ text: errTime, isError: true });
        Alert.alert('Ошибка', errTime);
        return;
      }
      if (raw[i].date.trim() && !raw[i].time.trim()) {
        const msg = 'Введите время';
        setStatusMessage({ text: msg, isError: true });
        Alert.alert('Ошибка', msg);
        return;
      }
      if (!raw[i].date.trim() && raw[i].time.trim()) {
        const msg = 'Введите дату';
        setStatusMessage({ text: msg, isError: true });
        Alert.alert('Ошибка', msg);
        return;
      }
    }

    const items = raw
      .filter((x) => x.date.trim() && x.time.trim())
      .map((x) => {
        const digitsDate = x.date.replace(/\D/g, '');
        const apiDate = digitsToApiDate(digitsDate) ?? toApiDate(x.date.trim());
        const time = digitsToTime(x.time.trim());
        if (!apiDate || !time) return null;
        return {
          date: apiDate,
          time,
        };
      })
      .filter((x): x is { date: string; time: string } => x !== null);

    if (items.length === 0) {
      const msg = 'Неверный формат. Дата: ДД.ММ.ГГ, Время: ЧЧ:ММ';
      setStatusMessage({ text: msg, isError: true });
      Alert.alert('Ошибка', msg);
      return;
    }

    const normalizeTime = (t: string) => t.slice(0, 5);
    const allSlots = [...slots.map((s) => ({ date: s.date, time: normalizeTime(s.time) }))];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const itemTime = normalizeTime(item.time);
      const conflictWithExisting = allSlots.some((s) => s.date === item.date && s.time === itemTime);
      const conflictWithNew = items
        .slice(0, i)
        .some((o) => o.date === item.date && normalizeTime(o.time) === itemTime);
      if (conflictWithExisting || conflictWithNew) {
        setStatusMessage({ text: 'Время уже занято!', isError: true });
        Alert.alert('Ошибка', 'Время уже занято!');
        return;
      }
      allSlots.push({ date: item.date, time: itemTime });
    }

    setSaving(true);
    setStatusMessage({ text: 'Сохранение...', isError: false });
    try {
      for (const item of items) {
        await createTutorSlot(item);
      }
      setNewDate1('');
      setNewTime1('');
      setNewDate2('');
      setNewTime2('');
      const data = await getTutorSlots();
      setSlots(data);
      setStatusMessage({ text: 'Слоты сохранены', isError: false });
      Alert.alert('Слоты сохранены');
    } catch (e: any) {
      if (e instanceof AuthError || e?.name === 'AuthError') {
        router.replace('/login');
        return;
      }
      const msg = e?.message ?? 'Не удалось добавить слоты';
      setStatusMessage({ text: msg, isError: true });
      Alert.alert('Ошибка', msg);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color="#181818" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable style={styles.backButton} onPress={() => router.back()}>
          <MaterialIcons name="chevron-left" size={24} color="#181818" />
        </Pressable>
        <Text style={styles.title}>Добавить слот</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {slots.map((slot) => (
          <View key={slot.id} style={styles.slotRow}>
            <View style={styles.slotCellDate}>
              <Text style={styles.slotText}>{toDisplayDate(slot.date)}</Text>
            </View>
            <View style={styles.slotCellDay}>
              <Text style={styles.slotText}>{dayFromDate(slot.date)}</Text>
            </View>
            <View style={styles.slotCellTime}>
              <Text style={styles.slotText}>{slot.time}</Text>
            </View>
          </View>
        ))}
        <View style={styles.slotRow}>
          <View style={styles.slotCellDate}>
            <TextInput
              style={styles.slotInput}
              placeholder="Дата (ДД.ММ.ГГ)"
              placeholderTextColor="#9B9B9B"
              value={newDate1}
              onChangeText={(t) => {
                setStatusMessage(null);
                setNewDate1(formatDateInput(t));
              }}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.slotCellDay} />
          <View style={styles.slotCellTime}>
            <TextInput
              style={styles.slotInput}
              placeholder="Время (ЧЧ:ММ)"
              placeholderTextColor="#9B9B9B"
              value={newTime1}
              onChangeText={(t) => {
                setStatusMessage(null);
                setNewTime1(formatTimeInput(t));
              }}
              keyboardType="numeric"
            />
          </View>
        </View>
        <View style={styles.slotRow}>
          <View style={styles.slotCellDate}>
            <TextInput
              style={styles.slotInput}
              placeholder="Дата (ДД.ММ.ГГ)"
              placeholderTextColor="#9B9B9B"
              value={newDate2}
              onChangeText={(t) => {
                setStatusMessage(null);
                setNewDate2(formatDateInput(t));
              }}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.slotCellDay} />
          <View style={styles.slotCellTime}>
            <TextInput
              style={styles.slotInput}
              placeholder="Время (ЧЧ:ММ)"
              placeholderTextColor="#9B9B9B"
              value={newTime2}
              onChangeText={(t) => {
                setStatusMessage(null);
                setNewTime2(formatTimeInput(t));
              }}
              keyboardType="numeric"
            />
          </View>
        </View>

        {statusMessage ? (
          <Text
            style={[
              styles.statusMessage,
              statusMessage.isError ? styles.statusMessageError : styles.statusMessageSuccess,
            ]}
          >
            {statusMessage.text}
          </Text>
        ) : null}

        <Pressable
          style={[styles.primaryButton, saving && styles.buttonDisabled]}
          onPress={handleSave}
          disabled={saving}
        >
          <Text style={styles.primaryButtonText}>{saving ? 'Сохранение...' : 'Сохранить'}</Text>
        </Pressable>
        <Pressable style={styles.secondaryButton} onPress={() => router.back()} disabled={saving}>
          <Text style={styles.secondaryButtonText}>Отмена</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  title: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    lineHeight: 24,
    fontFamily: 'Inter-Regular',
    color: '#181818',
  },
  content: {
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  slotRow: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#1E1E1E',
    marginBottom: 12,
    backgroundColor: '#fff',
    minHeight: 52,
  },
  slotCellDate: {
    flex: 1.6,
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  slotCellDay: {
    width: 64,
    justifyContent: 'center',
    alignItems: 'center',
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: '#1E1E1E',
  },
  slotCellTime: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 12,
  },
  slotText: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: 'Inter-Regular',
    color: '#181818',
  },
  slotInput: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: 'Inter-Regular',
    color: '#181818',
    padding: 0,
  },
  statusMessage: {
    marginTop: 16,
    fontSize: 14,
    lineHeight: 20,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  statusMessageError: {
    color: '#E02D2D',
  },
  statusMessageSuccess: {
    color: '#181818',
  },
  primaryButton: {
    marginTop: 24,
    backgroundColor: '#111',
    borderWidth: 1,
    borderColor: '#111',
    paddingVertical: 16,
    alignItems: 'center',
    height: 52,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  primaryButtonText: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: 'Inter-Regular',
    color: '#FAFAFA',
  },
  secondaryButton: {
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#1E1E1E',
    paddingVertical: 16,
    alignItems: 'center',
    height: 52,
  },
  secondaryButtonText: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: 'Inter-Regular',
    color: '#181818',
  },
});
